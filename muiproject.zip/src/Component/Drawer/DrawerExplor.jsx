import React from 'react'
import Header from '../../Layout/Header/Header'

const DrawerExplor = (props) => {
  return (
    <div>
      <Header item={props.item}/>
    </div>
  )
}

export default DrawerExplor
